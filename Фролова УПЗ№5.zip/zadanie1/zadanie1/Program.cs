﻿using System;
using System.IO;

namespace zadanie1
{
    class Class1
    {
        [STAThread]
        static void Main(string[] args)
        {
            try
            {
                StreamWriter sw = new StreamWriter("C:\\Users\\q\\Desktop\\Фролова УПЗ\\111.txt");
                sw.WriteLine("Сегодня хороший день, хорошее настроение.");
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);
            }
            finally
            {
                Console.WriteLine("Настроение текста положительное");
                Console.ReadLine();
            }
        }
    }
}
